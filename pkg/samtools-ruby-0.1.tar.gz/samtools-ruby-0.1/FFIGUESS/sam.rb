require 'rubygems'
require'ffi'

module SAMTools
  extend FFI::Library
  ffi_lib'libSAMTools'
    class SamfileTX < FFI::Union
    layout(
           :tamr, tamFile,
           :bam, bamFile,
           :tamw, :pointer
    )
  end
# FIXME: Nested structures are not correctly supported at the moment.
# Please check the order of the declarations in the structure below.
#   class SamfileT < FFI::Struct
#     layout(
#            :type, :int,
#            :header, :pointer,
#            :x, SamfileTX
#     )
#   end
  attach_function :samopen, [ :string, :string, :pointer ], :pointer
  attach_function :samclose, [ :pointer ], :void
  attach_function :samread, [ :pointer, :pointer ], :int
  attach_function :samwrite, [ :pointer, :pointer ], :int
  attach_function :sampileup, [ :pointer, :int, bam_pileup_f, :pointer ], :int
  attach_function :samfaipath, [ :string ], :string
end