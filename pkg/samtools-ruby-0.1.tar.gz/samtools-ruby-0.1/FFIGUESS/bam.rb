  class BamHeaderT < FFI::Struct
    layout(
           :n_targets, int32_t,
           :target_name, :pointer,
           :target_len, :pointer,
           :dict, :pointer,
           :hash, :pointer,
           :rg2lib, :pointer,
           :l_text, :int,
           :text, :pointer
    )
    def text=(str)
      @text = FFI::MemoryPointer.from_string(str)
      self[:text] = @text
    end
    def text
      @text.get_string(0)
    end

  end
  BAM_FPAIRED = 1
  BAM_FPROPER_PAIR = 2
  BAM_FUNMAP = 4
  BAM_FMUNMAP = 8
  BAM_FREVERSE = 16
  BAM_FMREVERSE = 32
  BAM_FREAD1 = 64
  BAM_FREAD2 = 128
  BAM_FSECONDARY = 256
  BAM_FQCFAIL = 512
  BAM_FDUP = 1024
  BAM_OFDEC = 0
  BAM_OFHEX = 1
  BAM_OFSTR = 2
  BAM_DEF_MASK = (4|256|512|1024)
  BAM_CIGAR_SHIFT = 4
  BAM_CIGAR_MASK = ((1 << 4) -1)
  BAM_CMATCH = 0
  BAM_CINS = 1
  BAM_CDEL = 2
  BAM_CREF_SKIP = 3
  BAM_CSOFT_CLIP = 4
  BAM_CHARD_CLIP = 5
  BAM_CPAD = 6
  class Bam1CoreT < FFI::Struct
    layout(
           :tid, int32_t,
           :pos, int32_t,
           :bin, uint32_t,
           :qual, uint32_t,
           :l_qname, uint32_t,
           :flag, uint32_t,
           :n_cigar, uint32_t,
           :l_qseq, int32_t,
           :mtid, int32_t,
           :mpos, int32_t,
           :isize, int32_t
    )
  end
  class Bam1T < FFI::Struct
    layout(
           :core, Bam1CoreT,
           :l_aux, :int,
           :data_len, :int,
           :m_data, :int,
           :data, :pointer
    )
  end
  attach_function :sam_open, [ :string ], :pointer
  attach_function :sam_close, [ :pointer ], :void
  attach_function :sam_read1, [ :pointer, :pointer, :pointer ], :int
  attach_function :sam_header_read2, [ :string ], :pointer
  attach_function :sam_header_read, [ :pointer ], :pointer
  attach_function :sam_header_parse, [ :pointer ], :int
  attach_function :sam_header_parse_rg, [ :pointer ], :int
  attach_function :bam_strmap_put, [ :pointer, :string, :string ], :int
  attach_function :bam_strmap_get, [ :pointer, :string ], :string
  attach_function :bam_strmap_dup, [ :pointer ], :pointer
  attach_function :bam_strmap_init, [  ], :pointer
  attach_function :bam_strmap_destroy, [ :pointer ], :void
  attach_function :bam_header_init, [  ], :pointer
  attach_function :bam_header_destroy, [ :pointer ], :void
  attach_function :bam_header_read, [ :pointer ], :pointer
  attach_function :bam_header_write, [ :pointer, :pointer ], :int
  attach_function :bam_read1, [ :pointer, :pointer ], :int
  attach_function :bam_write1_core, [ :pointer, :pointer, :int, :pointer ], :int
  attach_function :bam_write1, [ :pointer, :pointer ], :int
  attach_function :bam_format1, [ :pointer, :pointer ], :string
  attach_function :bam_format1_core, [ :pointer, :pointer, :int ], :string
  attach_function :bam_get_library, [ :pointer, :pointer ], :string
  class BamPileup1T < FFI::Struct
    layout(
           :b, :pointer,
           :qpos, int32_t,
           :indel, :int,
           :level, :int,
           :is_del, uint32_t,
           :is_head, uint32_t,
           :is_tail, uint32_t
    )
  end
  attach_function :bam_plbuf_set_mask, [ :pointer, :int ], :void
  callback(:bam_pileup_f, [ uint32_t, uint32_t, :int, :pointer, :pointer ], :int)
  attach_function :bam_plbuf_reset, [ :pointer ], :void
  attach_function :bam_plbuf_init, [ :bam_pileup_f, :pointer ], :pointer
  attach_function :bam_plbuf_destroy, [ :pointer ], :void
  attach_function :bam_plbuf_push, [ :pointer, :pointer ], :int
  attach_function :bam_pileup_file, [ :pointer, :int, :bam_pileup_f, :pointer ], :int
  attach_function :bam_lplbuf_reset, [ :pointer ], :void
  attach_function :bam_lplbuf_init, [ :bam_pileup_f, :pointer ], :pointer
  attach_function :bam_lplbuf_destroy, [ :pointer ], :void
  attach_function :bam_lplbuf_push, [ :pointer, :pointer ], :int
  attach_function :bam_index_build, [ :string ], :int
  attach_function :bam_index_load, [ :string ], :pointer
  attach_function :bam_index_destroy, [ :pointer ], :void
  callback(:bam_fetch_f, [ :pointer, :pointer ], :int)
  attach_function :bam_fetch, [ :pointer, :pointer, :int, :int, :int, :pointer, :bam_fetch_f ], :int
  attach_function :bam_parse_region, [ :pointer, :string, :pointer, :pointer, :pointer ], :int
  attach_function :bam_aux_get, [ :pointer, [:char, 2] ], :pointer
  attach_function :bam_aux2i, [ :pointer ], int32_t
  attach_function :bam_aux2f, [ :pointer ], :float
  attach_function :bam_aux2d, [ :pointer ], :double
  attach_function :bam_aux2A, [ :pointer ], :char
  attach_function :bam_aux2Z, [ :pointer ], :string
  attach_function :bam_aux_del, [ :pointer, :pointer ], :int
  attach_function :bam_aux_append, [ :pointer, [:char, 2], :char, :int, :pointer ], :void
  attach_function :bam_aux_get_core, [ :pointer, [:char, 2] ], :pointer
  attach_function :bam_calend, [ :pointer, :pointer ], uint32_t
  attach_function :bam_cigar2qlen, [ :pointer, :pointer ], int32_t
  attach_function :bam_reg2bin, [ uint32_t, uint32_t ], :int
  attach_function :bam_copy1, [ :pointer, :pointer ], :pointer
  attach_function :bam_dup1, [ :pointer ], :pointer
